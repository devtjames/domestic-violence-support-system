<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <p class="text-sm font-medium text-teal-700">Support case</p>
                <h2 class="font-semibold text-xl text-gray-800 leading-tight"><?php echo e($case->case_reference); ?></h2>
            </div>
            <div class="flex flex-col gap-2 sm:flex-row">
                <?php if (isset($component)) { $__componentOriginal478a4e443e123e40e9b0316ec9819b1d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal478a4e443e123e40e9b0316ec9819b1d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.quick-exit-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('quick-exit-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal478a4e443e123e40e9b0316ec9819b1d)): ?>
<?php $attributes = $__attributesOriginal478a4e443e123e40e9b0316ec9819b1d; ?>
<?php unset($__attributesOriginal478a4e443e123e40e9b0316ec9819b1d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal478a4e443e123e40e9b0316ec9819b1d)): ?>
<?php $component = $__componentOriginal478a4e443e123e40e9b0316ec9819b1d; ?>
<?php unset($__componentOriginal478a4e443e123e40e9b0316ec9819b1d); ?>
<?php endif; ?>
                <a href="<?php echo e(route('cases.index')); ?>" class="inline-flex justify-center rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">My Cases</a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-10">
        <div class="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
            <?php echo $__env->make('admin.partials.feedback', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <?php if (isset($component)) { $__componentOriginalf7c968390c23667a94d0345fda6af8fe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf7c968390c23667a94d0345fda6af8fe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.privacy-reminder','data' => ['class' => 'mb-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('privacy-reminder'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf7c968390c23667a94d0345fda6af8fe)): ?>
<?php $attributes = $__attributesOriginalf7c968390c23667a94d0345fda6af8fe; ?>
<?php unset($__attributesOriginalf7c968390c23667a94d0345fda6af8fe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf7c968390c23667a94d0345fda6af8fe)): ?>
<?php $component = $__componentOriginalf7c968390c23667a94d0345fda6af8fe; ?>
<?php unset($__componentOriginalf7c968390c23667a94d0345fda6af8fe); ?>
<?php endif; ?>

            <article class="rounded-md border border-gray-200 bg-white p-6 shadow-sm sm:p-8">
                <div class="flex flex-wrap items-center gap-3">
                    <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $case->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($case->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
                    <span class="inline-flex rounded-md px-2.5 py-1 text-xs font-semibold capitalize ring-1 <?php echo e($case->urgency === 'critical' ? 'bg-rose-50 text-rose-700 ring-rose-200' : ($case->urgency === 'high' ? 'bg-amber-50 text-amber-700 ring-amber-200' : 'bg-gray-100 text-gray-700 ring-gray-200')); ?>">
                        <?php echo e(\Illuminate\Support\Str::headline($case->urgency)); ?>

                    </span>
                    <span class="text-sm text-gray-600"><?php echo e($case->abuseType->name); ?></span>
                </div>

                <h1 class="mt-6 text-2xl font-semibold text-gray-900"><?php echo e($case->subject); ?></h1>

                <dl class="mt-6 grid gap-5 border-y border-gray-200 py-6 sm:grid-cols-2">
                    <div>
                        <dt class="text-sm font-semibold text-gray-900">Case Reference</dt>
                        <dd class="mt-1 text-sm text-gray-600"><?php echo e($case->case_reference); ?></dd>
                    </div>
                    <div>
                        <dt class="text-sm font-semibold text-gray-900">Submitted</dt>
                        <dd class="mt-1 text-sm text-gray-600"><?php echo e($case->created_at->format('M j, Y g:i A')); ?></dd>
                    </div>
                    <div>
                        <dt class="text-sm font-semibold text-gray-900">Preferred Contact</dt>
                        <dd class="mt-1 text-sm text-gray-600"><?php echo e($contactMethods[$case->preferred_contact_method] ?? 'No preference'); ?></dd>
                    </div>
                    <div>
                        <dt class="text-sm font-semibold text-gray-900">Safe Contact Time</dt>
                        <dd class="mt-1 text-sm text-gray-600"><?php echo e($case->safe_contact_time ?: 'Not provided'); ?></dd>
                    </div>
                    <div>
                        <dt class="text-sm font-semibold text-gray-900">Assigned Officer</dt>
                        <dd class="mt-1 text-sm text-gray-600"><?php echo e($case->assignedOfficer?->name ?? 'Not assigned yet'); ?></dd>
                    </div>
                    <div>
                        <dt class="text-sm font-semibold text-gray-900">Last Updated</dt>
                        <dd class="mt-1 text-sm text-gray-600"><?php echo e($case->updated_at->format('M j, Y g:i A')); ?></dd>
                    </div>
                </dl>

                <div class="mt-6">
                    <h2 class="text-base font-semibold text-gray-900">Description</h2>
                    <p class="mt-3 whitespace-pre-line text-sm leading-7 text-gray-700"><?php echo e($case->description); ?></p>
                </div>

                <?php if($case->safe_contact_instruction): ?>
                    <div class="mt-6 rounded-md border border-teal-200 bg-teal-50 p-4">
                        <h2 class="text-sm font-semibold text-teal-900">Safe Contact Instructions</h2>
                        <p class="mt-2 whitespace-pre-line text-sm leading-6 text-teal-900"><?php echo e($case->safe_contact_instruction); ?></p>
                    </div>
                <?php endif; ?>
            </article>

            <?php echo $__env->make('cases.partials.attachments', [
                'canUploadAttachments' => $case->status !== \App\Models\SupportCase::STATUS_CLOSED,
                'uploadAction' => route('cases.attachments.store', $case),
                'canDownloadAttachments' => true,
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <?php echo $__env->make('cases.partials.message-thread', [
                'canSendMessage' => $case->assigned_officer_id !== null && $case->status !== \App\Models\SupportCase::STATUS_CLOSED,
                'messageAction' => route('cases.messages.store', $case),
                'messageDisabledNotice' => $case->assigned_officer_id === null
                    ? 'A support officer must be assigned before private messages can be sent.'
                    : ($case->status === \App\Models\SupportCase::STATUS_CLOSED ? 'This case is closed, so new private messages are disabled.' : null),
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\mailp\Documents\VIBECODE\PROJECTS\domestic-support\resources\views\cases\show.blade.php ENDPATH**/ ?>