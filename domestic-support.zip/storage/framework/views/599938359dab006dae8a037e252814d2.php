<!DOCTYPE html>
<?php ($platformName = \App\Models\SystemSetting::platformName()); ?>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta name="robots" content="noindex, nofollow">

        <title><?php echo e($platformName); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=inter:400,500,600,700&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="font-sans text-gray-900 antialiased" data-quick-exit-url="<?php echo e(route('public.quick-exit')); ?>">
        <div class="flex min-h-screen flex-col items-center bg-slate-50 px-4 pt-8 sm:justify-center sm:pt-0">
            <div class="w-full max-w-md text-center">
                <a href="<?php echo e(route('home')); ?>" class="inline-flex items-center justify-center">
                    <?php if (isset($component)) { $__componentOriginal8892e718f3d0d7a916180885c6f012e7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8892e718f3d0d7a916180885c6f012e7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.application-logo','data' => ['class' => 'h-16 w-16']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-16 w-16']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $attributes = $__attributesOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $component = $__componentOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__componentOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
                </a>
                <p class="mt-3 truncate text-sm font-semibold text-gray-900"><?php echo e($platformName); ?></p>
                <p class="mt-1 max-w-sm text-sm text-gray-600">Private access for registered users, support officers, and administrators.</p>
            </div>

            <div class="mt-6 w-full overflow-hidden rounded-2xl border border-slate-200 bg-white px-6 py-6 shadow-panel sm:max-w-md sm:px-8">
                <?php echo e($slot); ?>

            </div>

            <a href="<?php echo e(route('home')); ?>" class="mt-6 text-sm font-medium text-teal-700 hover:text-teal-800">Back to public website</a>
            <div class="mt-4 flex flex-col items-center gap-3">
                <?php if (isset($component)) { $__componentOriginal478a4e443e123e40e9b0316ec9819b1d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal478a4e443e123e40e9b0316ec9819b1d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.quick-exit-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('quick-exit-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal478a4e443e123e40e9b0316ec9819b1d)): ?>
<?php $attributes = $__attributesOriginal478a4e443e123e40e9b0316ec9819b1d; ?>
<?php unset($__attributesOriginal478a4e443e123e40e9b0316ec9819b1d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal478a4e443e123e40e9b0316ec9819b1d)): ?>
<?php $component = $__componentOriginal478a4e443e123e40e9b0316ec9819b1d; ?>
<?php unset($__componentOriginal478a4e443e123e40e9b0316ec9819b1d); ?>
<?php endif; ?>
                <p class="max-w-sm text-center text-xs leading-5 text-gray-600">Quick Exit does not erase browser history or device activity.</p>
            </div>
        </div>
    </body>
</html>
<?php /**PATH C:\Users\mailp\Documents\VIBECODE\PROJECTS\domestic-support\resources\views\layouts\guest.blade.php ENDPATH**/ ?>