<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <p class="text-sm font-medium text-rose-700">Resource details</p>
                <h2 class="font-semibold text-xl text-gray-800 leading-tight"><?php echo e($resource->organization_name); ?></h2>
            </div>
            <div class="flex flex-col gap-2 sm:flex-row">
                <a href="<?php echo e(route('admin.resources.index')); ?>" class="inline-flex justify-center rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">Back</a>
                <a href="<?php echo e(route('admin.resources.edit', $resource)); ?>" class="inline-flex justify-center rounded-md bg-rose-700 px-4 py-2 text-sm font-semibold text-white hover:bg-rose-800">Edit</a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-10">
        <div class="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
            <?php echo $__env->make('admin.partials.feedback', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <article class="rounded-md border border-gray-200 bg-white p-6 shadow-sm sm:p-8">
                <div class="flex flex-wrap items-center gap-3">
                    <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $resource->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($resource->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
                    <span class="rounded-md bg-indigo-50 px-2.5 py-1 text-xs font-semibold text-indigo-700 ring-1 ring-indigo-200"><?php echo e($resource->resource_type); ?></span>
                    <span class="text-sm text-gray-600"><?php echo e($resource->location); ?></span>
                </div>

                <p class="mt-6 whitespace-pre-line text-base leading-8 text-gray-700"><?php echo e($resource->description); ?></p>

                <dl class="mt-8 grid gap-5 border-t border-gray-200 pt-6 sm:grid-cols-2">
                    <div>
                        <dt class="text-sm font-semibold text-gray-900">Availability</dt>
                        <dd class="mt-1 text-sm text-gray-600"><?php echo e($resource->availability); ?></dd>
                    </div>
                    <div>
                        <dt class="text-sm font-semibold text-gray-900">Phone</dt>
                        <dd class="mt-1 text-sm text-gray-600"><?php echo e($resource->phone ?: 'Not provided'); ?></dd>
                    </div>
                    <div>
                        <dt class="text-sm font-semibold text-gray-900">Email</dt>
                        <dd class="mt-1 text-sm text-gray-600">
                            <?php if($resource->email): ?>
                                <a href="mailto:<?php echo e($resource->email); ?>" class="font-medium text-rose-700 hover:text-rose-800"><?php echo e($resource->email); ?></a>
                            <?php else: ?>
                                Not provided
                            <?php endif; ?>
                        </dd>
                    </div>
                    <div>
                        <dt class="text-sm font-semibold text-gray-900">Website</dt>
                        <dd class="mt-1 break-all text-sm text-gray-600">
                            <?php if($resource->website): ?>
                                <a href="<?php echo e($resource->website); ?>" class="font-medium text-rose-700 hover:text-rose-800" rel="noopener noreferrer" target="_blank"><?php echo e($resource->website); ?></a>
                            <?php else: ?>
                                Not provided
                            <?php endif; ?>
                        </dd>
                    </div>
                    <div class="sm:col-span-2">
                        <dt class="text-sm font-semibold text-gray-900">Address</dt>
                        <dd class="mt-1 text-sm text-gray-600"><?php echo e($resource->address ?: 'Not provided'); ?></dd>
                    </div>
                </dl>
            </article>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\mailp\Documents\VIBECODE\PROJECTS\domestic-support\resources\views\admin\resources\show.blade.php ENDPATH**/ ?>