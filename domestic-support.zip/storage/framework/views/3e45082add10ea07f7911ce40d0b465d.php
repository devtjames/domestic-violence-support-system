<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <p class="text-sm font-medium text-teal-700">Registered user area</p>
                <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                    <?php echo e(__('Dashboard')); ?>

                </h2>
            </div>
            <span class="inline-flex w-fit rounded-md bg-emerald-50 px-3 py-1 text-sm font-medium text-emerald-700 ring-1 ring-emerald-200">
                <?php echo e(ucfirst(Auth::user()->account_status)); ?>

            </span>
        </div>
     <?php $__env->endSlot(); ?>

    <?php
        $cardClasses = [
            'teal' => 'bg-teal-50 text-teal-800 ring-teal-100',
            'emerald' => 'bg-emerald-50 text-emerald-800 ring-emerald-100',
            'indigo' => 'bg-indigo-50 text-indigo-800 ring-indigo-100',
            'slate' => 'bg-slate-50 text-slate-800 ring-slate-100',
        ];
    ?>

    <div class="py-10">
        <div class="mx-auto max-w-7xl space-y-8 px-4 sm:px-6 lg:px-8">
            <?php if (isset($component)) { $__componentOriginalf7c968390c23667a94d0345fda6af8fe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf7c968390c23667a94d0345fda6af8fe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.privacy-reminder','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('privacy-reminder'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf7c968390c23667a94d0345fda6af8fe)): ?>
<?php $attributes = $__attributesOriginalf7c968390c23667a94d0345fda6af8fe; ?>
<?php unset($__attributesOriginalf7c968390c23667a94d0345fda6af8fe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf7c968390c23667a94d0345fda6af8fe)): ?>
<?php $component = $__componentOriginalf7c968390c23667a94d0345fda6af8fe; ?>
<?php unset($__componentOriginalf7c968390c23667a94d0345fda6af8fe); ?>
<?php endif; ?>

            <section class="grid gap-6 lg:grid-cols-3">
                <div class="bg-white p-6 shadow-sm sm:rounded-lg lg:col-span-2">
                    <p class="text-sm font-semibold uppercase text-teal-700">Welcome back</p>
                    <h3 class="mt-2 text-2xl font-semibold text-gray-900"><?php echo e(Auth::user()->name); ?></h3>
                    <p class="mt-3 max-w-2xl text-sm leading-6 text-gray-600">
                        Track your support requests using case references and status updates. Dashboard cards avoid showing private descriptions, message text, and safe contact details.
                    </p>
                    <div class="mt-5 flex flex-col gap-3 sm:flex-row">
                        <a href="<?php echo e(route('cases.create')); ?>" class="inline-flex justify-center rounded-md bg-teal-700 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-teal-800 focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2">Request Support</a>
                        <a href="<?php echo e(route('cases.index')); ?>" class="inline-flex justify-center rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">My Cases</a>
                        <a href="<?php echo e(route('cases.index')); ?>" class="inline-flex justify-center rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">Read Messages</a>
                        <a href="<?php echo e(route('public.resources')); ?>" class="inline-flex justify-center rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">View Resources</a>
                    </div>
                </div>

                <div class="bg-white p-6 shadow-sm sm:rounded-lg">
                    <h3 class="text-base font-semibold text-gray-900">Account Access</h3>
                    <dl class="mt-4 space-y-3 text-sm">
                        <div class="flex items-center justify-between">
                            <dt class="text-gray-600">Role</dt>
                            <dd class="font-medium text-gray-900">User</dd>
                        </div>
                        <div class="flex items-center justify-between">
                            <dt class="text-gray-600">Profile</dt>
                            <dd>
                                <a href="<?php echo e(route('profile.edit')); ?>" class="font-medium text-teal-700 hover:text-teal-800">Manage</a>
                            </dd>
                        </div>
                    </dl>
                </div>
            </section>

            <section class="metric-grid grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                <?php $__currentLoopData = $summaryCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="metric-card rounded-lg p-5 ring-1 <?php echo e($cardClasses[$card['tone']] ?? $cardClasses['slate']); ?>">
                        <p class="text-sm font-medium"><?php echo e($card['label']); ?></p>
                        <p class="mt-3 text-3xl font-semibold tracking-normal"><?php echo e(number_format($card['value'])); ?></p>
                        <p class="mt-2 text-sm leading-6"><?php echo e($card['helper']); ?></p>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>

            <section class="grid gap-6 xl:grid-cols-5">
                <div class="bg-white p-6 shadow-sm sm:rounded-lg xl:col-span-3">
                    <div class="flex items-center justify-between gap-4">
                        <div>
                            <h3 class="text-base font-semibold text-gray-900">My Recent Cases</h3>
                            <p class="mt-1 text-sm text-gray-600">References, status, urgency, and unread counts only.</p>
                        </div>
                        <a href="<?php echo e(route('cases.index')); ?>" class="text-sm font-semibold text-teal-700 hover:text-teal-800">View all</a>
                    </div>

                    <div class="mt-5 overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200 text-sm">
                            <thead>
                                <tr class="text-left text-xs font-semibold uppercase tracking-normal text-gray-500">
                                    <th scope="col" class="py-3 pr-4">Reference</th>
                                    <th scope="col" class="px-4 py-3">Type</th>
                                    <th scope="col" class="px-4 py-3">Urgency</th>
                                    <th scope="col" class="px-4 py-3">Status</th>
                                    <th scope="col" class="py-3 pl-4">Updated</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-100">
                                <?php $__empty_1 = true; $__currentLoopData = $recentCases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $case): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td class="whitespace-nowrap py-3 pr-4">
                                            <a href="<?php echo e(route('cases.show', $case)); ?>" class="font-semibold text-teal-700 hover:text-teal-800"><?php echo e($case->case_reference); ?></a>
                                            <?php if($case->unread_messages_count > 0): ?>
                                                <span class="ml-2 inline-flex rounded-md bg-indigo-50 px-2 py-0.5 text-xs font-semibold text-indigo-700 ring-1 ring-indigo-200"><?php echo e($case->unread_messages_count); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="whitespace-nowrap px-4 py-3 text-gray-700"><?php echo e($case->abuseType?->name ?? 'Unspecified'); ?></td>
                                        <td class="whitespace-nowrap px-4 py-3 text-gray-700"><?php echo e(str($case->urgency)->headline()); ?></td>
                                        <td class="whitespace-nowrap px-4 py-3"><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $case->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($case->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                                        <td class="whitespace-nowrap py-3 pl-4 text-gray-600"><?php echo e($case->updated_at->format('M j, Y')); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="py-8 text-center text-sm text-gray-500">Your submitted support requests will appear here.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="bg-white p-6 shadow-sm sm:rounded-lg xl:col-span-2">
                    <h3 class="text-base font-semibold text-gray-900">Recent Messages</h3>
                    <p class="mt-1 text-sm text-gray-600">Message content stays inside the case conversation.</p>

                    <div class="mt-5 space-y-4">
                        <?php $__empty_1 = true; $__currentLoopData = $recentMessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <article class="border-b border-gray-100 pb-4 last:border-b-0 last:pb-0">
                                <div class="flex items-start justify-between gap-4">
                                    <div>
                                        <a href="<?php echo e(route('cases.show', $message->supportCase)); ?>" class="text-sm font-semibold text-teal-700 hover:text-teal-800"><?php echo e($message->supportCase->case_reference); ?></a>
                                        <p class="mt-1 text-sm text-gray-600">
                                            <?php echo e($message->sender_id === Auth::id() ? 'You sent a message' : 'Support officer replied'); ?>

                                        </p>
                                    </div>
                                    <?php if($message->receiver_id === Auth::id() && $message->read_at === null): ?>
                                        <span class="shrink-0 rounded-md bg-indigo-50 px-2 py-1 text-xs font-semibold text-indigo-700 ring-1 ring-indigo-200">Unread</span>
                                    <?php endif; ?>
                                </div>
                                <time datetime="<?php echo e($message->created_at->toIso8601String()); ?>" class="mt-2 block text-xs text-gray-500"><?php echo e($message->created_at->format('M j, Y g:i A')); ?></time>
                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="rounded-md bg-gray-50 p-4 text-sm text-gray-600">Private case messages will appear here after a support officer is assigned.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </section>

            <section class="grid gap-6 lg:grid-cols-3">
                <div class="bg-white p-6 shadow-sm sm:rounded-lg">
                    <h3 class="text-base font-semibold text-gray-900">Latest Case Updates</h3>
                    <p class="mt-1 text-sm text-gray-600">Public-safe activity labels for your cases.</p>

                    <div class="mt-5 space-y-4">
                        <?php $__empty_1 = true; $__currentLoopData = $recentCaseUpdates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <article class="border-b border-gray-100 pb-4 last:border-b-0 last:pb-0">
                                <a href="<?php echo e(route('cases.show', $activity->supportCase)); ?>" class="text-sm font-semibold text-teal-700 hover:text-teal-800"><?php echo e($activity->supportCase->case_reference); ?></a>
                                <p class="mt-1 text-sm text-gray-700"><?php echo e($activity->label()); ?></p>
                                <time datetime="<?php echo e($activity->created_at->toIso8601String()); ?>" class="mt-1 block text-xs text-gray-500"><?php echo e($activity->created_at->format('M j, Y g:i A')); ?></time>
                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="rounded-md bg-gray-50 p-4 text-sm text-gray-600">Case updates will appear here after a request is submitted.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="bg-white p-6 shadow-sm sm:rounded-lg">
                    <div class="flex items-center justify-between gap-4">
                        <div>
                            <h3 class="text-base font-semibold text-gray-900">Awareness Articles</h3>
                            <p class="mt-1 text-sm text-gray-600">Recently published guidance.</p>
                        </div>
                        <a href="<?php echo e(route('public.awareness')); ?>" class="text-sm font-semibold text-teal-700 hover:text-teal-800">Browse</a>
                    </div>

                    <div class="mt-5 space-y-4">
                        <?php $__empty_1 = true; $__currentLoopData = $awarenessArticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <article class="border-b border-gray-100 pb-4 last:border-b-0 last:pb-0">
                                <a href="<?php echo e(route('public.awareness.show', $article)); ?>" class="text-sm font-semibold text-gray-900 hover:text-teal-700"><?php echo e($article->title); ?></a>
                                <p class="mt-1 text-xs font-medium text-teal-700"><?php echo e($article->category?->name ?? 'Awareness'); ?></p>
                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="rounded-md bg-gray-50 p-4 text-sm text-gray-600">Published awareness articles will appear here.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="bg-white p-6 shadow-sm sm:rounded-lg">
                    <div class="flex items-center justify-between gap-4">
                        <div>
                            <h3 class="text-base font-semibold text-gray-900">Support Resources</h3>
                            <p class="mt-1 text-sm text-gray-600">Active organizations listed by the platform.</p>
                        </div>
                        <a href="<?php echo e(route('public.resources')); ?>" class="text-sm font-semibold text-teal-700 hover:text-teal-800">View</a>
                    </div>

                    <div class="mt-5 space-y-4">
                        <?php $__empty_1 = true; $__currentLoopData = $supportResources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <article class="border-b border-gray-100 pb-4 last:border-b-0 last:pb-0">
                                <p class="text-sm font-semibold text-gray-900"><?php echo e($resource->organization_name); ?></p>
                                <p class="mt-1 text-sm text-gray-600"><?php echo e($resource->resource_type); ?> &middot; <?php echo e($resource->location); ?></p>
                                <p class="mt-1 text-xs text-gray-500"><?php echo e($resource->availability); ?></p>
                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="rounded-md bg-gray-50 p-4 text-sm text-gray-600">Active support resources will appear here.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </section>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\mailp\Documents\VIBECODE\PROJECTS\domestic-support\resources\views/dashboard.blade.php ENDPATH**/ ?>