<section class="rounded-md border border-gray-200 bg-white p-6 shadow-sm">
    <div>
        <h2 class="text-base font-semibold text-gray-900">Case Activity History</h2>
        <p class="mt-1 text-sm leading-6 text-gray-600">Staff-only audit trail for major case actions. Private note and message contents are not copied into this history.</p>
    </div>
    <div class="mt-5 space-y-4">
        <?php $__empty_1 = true; $__currentLoopData = $case->activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <article class="rounded-md border border-gray-200 p-4">
                <div class="flex flex-col gap-1 sm:flex-row sm:items-start sm:justify-between">
                    <div>
                        <p class="text-sm font-semibold text-gray-900"><?php echo e($activity->label()); ?></p>
                        <p class="mt-1 text-sm leading-6 text-gray-600"><?php echo e($activity->description); ?></p>
                    </div>
                    <time datetime="<?php echo e($activity->created_at->toISOString()); ?>" class="text-xs text-gray-500"><?php echo e($activity->created_at->format('M j, Y g:i A')); ?></time>
                </div>
                <dl class="mt-3 grid gap-3 text-xs text-gray-600 sm:grid-cols-2 lg:grid-cols-4">
                    <div>
                        <dt class="font-semibold text-gray-800">Actor</dt>
                        <dd class="mt-1"><?php echo e($activity->actor?->name ?? 'System'); ?></dd>
                    </div>
                    <div>
                        <dt class="font-semibold text-gray-800">Previous</dt>
                        <dd class="mt-1"><?php echo e($activity->previous_value ?: 'None'); ?></dd>
                    </div>
                    <div>
                        <dt class="font-semibold text-gray-800">New</dt>
                        <dd class="mt-1"><?php echo e($activity->new_value ?: 'None'); ?></dd>
                    </div>
                    <div>
                        <dt class="font-semibold text-gray-800">IP Address</dt>
                        <dd class="mt-1 break-all"><?php echo e($activity->ip_address ?: 'Not recorded'); ?></dd>
                    </div>
                </dl>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-sm leading-6 text-gray-600">No activity has been recorded yet.</p>
        <?php endif; ?>
    </div>
</section>
<?php /**PATH C:\Users\mailp\Documents\VIBECODE\PROJECTS\domestic-support\resources\views/cases/partials/activity-list.blade.php ENDPATH**/ ?>