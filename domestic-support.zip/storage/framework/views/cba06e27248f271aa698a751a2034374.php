<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <p class="text-sm font-medium text-rose-700">Audit log detail</p>
                <h2 class="font-semibold text-xl text-gray-800 leading-tight"><?php echo e(str($log->action)->headline()); ?></h2>
            </div>
            <a href="<?php echo e(route('admin.audit-logs.index')); ?>" class="inline-flex w-fit justify-center rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">All Audit Logs</a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-10">
        <div class="mx-auto max-w-5xl space-y-6 px-4 sm:px-6 lg:px-8">
            <section class="rounded-md border border-gray-200 bg-white p-6 shadow-sm">
                <dl class="grid gap-5 sm:grid-cols-2">
                    <div>
                        <dt class="text-sm font-semibold text-gray-900">Timestamp</dt>
                        <dd class="mt-1 text-sm text-gray-600"><?php echo e($log->created_at->format('M j, Y g:i A')); ?></dd>
                    </div>
                    <div>
                        <dt class="text-sm font-semibold text-gray-900">Actor</dt>
                        <dd class="mt-1 text-sm text-gray-600"><?php echo e($log->actor?->name ?? 'System'); ?><?php echo e($log->actor?->role ? ' - '.str($log->actor->role)->headline() : ''); ?></dd>
                    </div>
                    <div>
                        <dt class="text-sm font-semibold text-gray-900">Module</dt>
                        <dd class="mt-1 text-sm text-gray-600"><?php echo e(str($log->module)->headline()); ?></dd>
                    </div>
                    <div>
                        <dt class="text-sm font-semibold text-gray-900">Action</dt>
                        <dd class="mt-1 text-sm text-gray-600"><?php echo e($log->action); ?></dd>
                    </div>
                    <div class="sm:col-span-2">
                        <dt class="text-sm font-semibold text-gray-900">Description</dt>
                        <dd class="mt-1 text-sm text-gray-600"><?php echo e($log->description); ?></dd>
                    </div>
                    <div>
                        <dt class="text-sm font-semibold text-gray-900">IP Address</dt>
                        <dd class="mt-1 text-sm text-gray-600"><?php echo e($log->ip_address ?: 'Not recorded'); ?></dd>
                    </div>
                    <div>
                        <dt class="text-sm font-semibold text-gray-900">Auditable Record</dt>
                        <dd class="mt-1 text-sm text-gray-600"><?php echo e($log->auditable_type ? class_basename($log->auditable_type).' #'.$log->auditable_id : 'Not linked'); ?></dd>
                    </div>
                    <div class="sm:col-span-2">
                        <dt class="text-sm font-semibold text-gray-900">User Agent</dt>
                        <dd class="mt-1 break-words text-sm text-gray-600"><?php echo e($log->user_agent ?: 'Not recorded'); ?></dd>
                    </div>
                </dl>
            </section>

            <section class="rounded-md border border-gray-200 bg-white p-6 shadow-sm">
                <h3 class="text-base font-semibold text-gray-900">Metadata</h3>
                <?php if($log->metadata): ?>
                    <dl class="mt-4 grid gap-3 text-sm sm:grid-cols-2">
                        <?php $__currentLoopData = $log->metadata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="rounded-md bg-gray-50 p-3">
                                <dt class="font-semibold text-gray-900"><?php echo e(str($key)->headline()); ?></dt>
                                <dd class="mt-1 break-words text-gray-600"><?php echo e(is_scalar($value) ? $value : json_encode($value)); ?></dd>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </dl>
                <?php else: ?>
                    <p class="mt-3 rounded-md bg-gray-50 p-4 text-sm text-gray-600">No extra metadata was recorded.</p>
                <?php endif; ?>
            </section>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\mailp\Documents\VIBECODE\PROJECTS\domestic-support\resources\views\admin\audit-logs\show.blade.php ENDPATH**/ ?>