<!DOCTYPE html>
<?php ($platformName = \App\Models\SystemSetting::platformName()); ?>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta name="robots" content="noindex, nofollow">

        <title><?php echo e($platformName); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=inter:400,500,600,700&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="app-body bg-slate-50 font-sans text-slate-900 antialiased" data-workspace="<?php echo e(Auth::user()->role); ?>" data-quick-exit-url="<?php echo e(route('public.quick-exit')); ?>">
        <div class="min-h-screen bg-slate-50">
            <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <div class="min-w-0 pt-16 lg:pl-72 lg:pt-0">
                <?php if(isset($header)): ?>
                    <header class="workspace-header border-b border-slate-200/80 bg-white/90 backdrop-blur">
                        <div class="mx-auto max-w-7xl px-4 py-5 sm:px-6 lg:px-8 lg:py-6">
                            <?php echo e($header); ?>

                        </div>
                    </header>
                <?php endif; ?>

                <main class="app-workspace min-w-0 overflow-x-clip">
                    <?php echo e($slot); ?>

                </main>
            </div>
        </div>
    </body>
</html>
<?php /**PATH C:\Users\mailp\Documents\VIBECODE\PROJECTS\domestic-support\resources\views\layouts\app.blade.php ENDPATH**/ ?>