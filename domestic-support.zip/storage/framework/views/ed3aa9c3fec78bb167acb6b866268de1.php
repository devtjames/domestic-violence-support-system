<?php if (isset($component)) { $__componentOriginal58c831a7c3cbf004f2e66a23aed50e5b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal58c831a7c3cbf004f2e66a23aed50e5b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.public-layout','data' => ['title' => $article->title]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('public-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($article->title)]); ?>
    <main>
        <article>
            <header class="public-page-hero bg-gradient-to-br from-slate-950 via-slate-900 to-teal-950 py-20 text-white">
                <div class="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
                    <p class="text-sm font-semibold uppercase text-teal-100"><?php echo e($article->category->name); ?></p>
                    <h1 class="mt-3 text-4xl font-bold leading-tight"><?php echo e($article->title); ?></h1>
                    <p class="mt-5 text-base leading-7 text-gray-100"><?php echo e($article->short_description); ?></p>
                </div>
            </header>

            <div class="bg-white py-12">
                <div class="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
                    <?php if($article->featured_image): ?>
                        <img src="<?php echo e(Storage::url($article->featured_image)); ?>" alt="" class="mb-8 h-72 w-full rounded-md object-cover">
                    <?php endif; ?>

                    <div class="whitespace-pre-line text-base leading-8 text-gray-700"><?php echo e($article->content); ?></div>

                    <p class="mt-8 text-sm text-gray-500">
                        Published <?php echo e($article->published_at?->format('M j, Y')); ?> by <?php echo e($article->author->name); ?>.
                    </p>
                    <div class="mt-10 border-t border-gray-200 pt-6">
                        <a href="<?php echo e(route('public.awareness')); ?>" class="text-sm font-semibold text-teal-700 hover:text-teal-800">Back to awareness</a>
                    </div>
                </div>
            </div>
        </article>
    </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal58c831a7c3cbf004f2e66a23aed50e5b)): ?>
<?php $attributes = $__attributesOriginal58c831a7c3cbf004f2e66a23aed50e5b; ?>
<?php unset($__attributesOriginal58c831a7c3cbf004f2e66a23aed50e5b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal58c831a7c3cbf004f2e66a23aed50e5b)): ?>
<?php $component = $__componentOriginal58c831a7c3cbf004f2e66a23aed50e5b; ?>
<?php unset($__componentOriginal58c831a7c3cbf004f2e66a23aed50e5b); ?>
<?php endif; ?>
<?php /**PATH C:\Users\mailp\Documents\VIBECODE\PROJECTS\domestic-support\resources\views\public\article.blade.php ENDPATH**/ ?>