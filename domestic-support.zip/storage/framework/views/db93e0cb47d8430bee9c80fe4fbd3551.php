<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['status']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['status']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $classes = match ($status) {
        'published', 'active', 'resolved' => 'bg-emerald-50 text-emerald-700 ring-emerald-200',
        'draft', 'submitted', 'closed', 'read' => 'bg-gray-100 text-gray-700 ring-gray-200',
        'archived', 'inactive', 'disabled' => 'bg-rose-50 text-rose-700 ring-rose-200',
        'new', 'under_review', 'assigned', 'in_progress', 'awaiting_user' => 'bg-indigo-50 text-indigo-700 ring-indigo-200',
        'responded', 'referred' => 'bg-amber-50 text-amber-700 ring-amber-200',
        default => 'bg-indigo-50 text-indigo-700 ring-indigo-200',
    };
?>

<span <?php echo e($attributes->merge(['class' => "inline-flex whitespace-nowrap rounded-md px-2.5 py-1 text-xs font-semibold capitalize ring-1 {$classes}"])); ?>>
    <?php echo e(str_replace('_', ' ', $status)); ?>

</span>
<?php /**PATH C:\Users\mailp\Documents\VIBECODE\PROJECTS\domestic-support\resources\views\components\status-badge.blade.php ENDPATH**/ ?>