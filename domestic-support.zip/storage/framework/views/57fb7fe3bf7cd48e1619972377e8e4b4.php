<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <p class="text-sm font-medium text-teal-700">Private support</p>
                <h2 class="font-semibold text-xl text-gray-800 leading-tight">Request Support</h2>
            </div>
            <?php if (isset($component)) { $__componentOriginal478a4e443e123e40e9b0316ec9819b1d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal478a4e443e123e40e9b0316ec9819b1d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.quick-exit-button','data' => ['class' => 'w-fit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('quick-exit-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-fit']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal478a4e443e123e40e9b0316ec9819b1d)): ?>
<?php $attributes = $__attributesOriginal478a4e443e123e40e9b0316ec9819b1d; ?>
<?php unset($__attributesOriginal478a4e443e123e40e9b0316ec9819b1d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal478a4e443e123e40e9b0316ec9819b1d)): ?>
<?php $component = $__componentOriginal478a4e443e123e40e9b0316ec9819b1d; ?>
<?php unset($__componentOriginal478a4e443e123e40e9b0316ec9819b1d); ?>
<?php endif; ?>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-10">
        <div class="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
            <?php echo $__env->make('admin.partials.feedback', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <?php if (isset($component)) { $__componentOriginalf7c968390c23667a94d0345fda6af8fe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf7c968390c23667a94d0345fda6af8fe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.privacy-reminder','data' => ['class' => 'mb-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('privacy-reminder'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf7c968390c23667a94d0345fda6af8fe)): ?>
<?php $attributes = $__attributesOriginalf7c968390c23667a94d0345fda6af8fe; ?>
<?php unset($__attributesOriginalf7c968390c23667a94d0345fda6af8fe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf7c968390c23667a94d0345fda6af8fe)): ?>
<?php $component = $__componentOriginalf7c968390c23667a94d0345fda6af8fe; ?>
<?php unset($__componentOriginalf7c968390c23667a94d0345fda6af8fe); ?>
<?php endif; ?>

            <?php if($abuseTypes->isEmpty()): ?>
                <div class="rounded-md border border-gray-200 bg-white p-6 text-sm text-gray-600 shadow-sm">
                    Support request categories are not available yet. Please try again later.
                </div>
            <?php else: ?>
                <?php echo $__env->make('cases.partials.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\mailp\Documents\VIBECODE\PROJECTS\domestic-support\resources\views\cases\create.blade.php ENDPATH**/ ?>