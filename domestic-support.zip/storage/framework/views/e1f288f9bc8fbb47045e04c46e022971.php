<?php if (isset($component)) { $__componentOriginal58c831a7c3cbf004f2e66a23aed50e5b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal58c831a7c3cbf004f2e66a23aed50e5b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.public-layout','data' => ['title' => 'Anonymous Request Submitted','robots' => 'noindex, nofollow']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('public-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Anonymous Request Submitted','robots' => 'noindex, nofollow']); ?>
    <main>
        <section class="bg-teal-950 py-16 text-white">
            <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
                <div class="max-w-3xl">
                    <p class="text-sm font-semibold uppercase text-teal-100">Request submitted</p>
                    <h1 class="mt-3 text-4xl font-bold leading-tight">Record these details now</h1>
                    <p class="mt-5 text-base leading-7 text-teal-50">
                        The access code is shown once. It is stored securely as a hash and cannot be recovered later.
                    </p>
                </div>
            </div>
        </section>

        <section class="bg-gray-50 py-12">
            <div class="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
                <div class="rounded-md border border-gray-200 bg-white p-6 shadow-sm sm:p-8">
                    <dl class="grid gap-5 sm:grid-cols-2">
                        <div>
                            <dt class="text-sm font-semibold text-gray-900">Case Reference</dt>
                            <dd class="mt-2 rounded-md bg-gray-100 px-4 py-3 font-mono text-lg font-semibold text-gray-900"><?php echo e($caseReference); ?></dd>
                        </div>
                        <div>
                            <dt class="text-sm font-semibold text-gray-900">Access Code</dt>
                            <dd class="mt-2 rounded-md bg-gray-100 px-4 py-3 font-mono text-lg font-semibold text-gray-900"><?php echo e($accessCode); ?></dd>
                        </div>
                    </dl>

                    <?php if (isset($component)) { $__componentOriginalf7c968390c23667a94d0345fda6af8fe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf7c968390c23667a94d0345fda6af8fe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.privacy-reminder','data' => ['class' => 'mt-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('privacy-reminder'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-6']); ?>
                        Anyone with both values can check the limited anonymous case status page. Keep them private and use a safer device where possible. Quick Exit does not erase browser history or device activity.
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf7c968390c23667a94d0345fda6af8fe)): ?>
<?php $attributes = $__attributesOriginalf7c968390c23667a94d0345fda6af8fe; ?>
<?php unset($__attributesOriginalf7c968390c23667a94d0345fda6af8fe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf7c968390c23667a94d0345fda6af8fe)): ?>
<?php $component = $__componentOriginalf7c968390c23667a94d0345fda6af8fe; ?>
<?php unset($__componentOriginalf7c968390c23667a94d0345fda6af8fe); ?>
<?php endif; ?>

                    <div class="mt-6 flex flex-col gap-3 sm:flex-row">
                        <a href="<?php echo e(route('anonymous.track.form')); ?>" class="inline-flex justify-center rounded-md bg-teal-700 px-4 py-2 text-sm font-semibold text-white hover:bg-teal-800">Track Anonymous Case</a>
                        <?php if (isset($component)) { $__componentOriginal478a4e443e123e40e9b0316ec9819b1d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal478a4e443e123e40e9b0316ec9819b1d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.quick-exit-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('quick-exit-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal478a4e443e123e40e9b0316ec9819b1d)): ?>
<?php $attributes = $__attributesOriginal478a4e443e123e40e9b0316ec9819b1d; ?>
<?php unset($__attributesOriginal478a4e443e123e40e9b0316ec9819b1d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal478a4e443e123e40e9b0316ec9819b1d)): ?>
<?php $component = $__componentOriginal478a4e443e123e40e9b0316ec9819b1d; ?>
<?php unset($__componentOriginal478a4e443e123e40e9b0316ec9819b1d); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
        </section>
    </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal58c831a7c3cbf004f2e66a23aed50e5b)): ?>
<?php $attributes = $__attributesOriginal58c831a7c3cbf004f2e66a23aed50e5b; ?>
<?php unset($__attributesOriginal58c831a7c3cbf004f2e66a23aed50e5b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal58c831a7c3cbf004f2e66a23aed50e5b)): ?>
<?php $component = $__componentOriginal58c831a7c3cbf004f2e66a23aed50e5b; ?>
<?php unset($__componentOriginal58c831a7c3cbf004f2e66a23aed50e5b); ?>
<?php endif; ?>
<?php /**PATH C:\Users\mailp\Documents\VIBECODE\PROJECTS\domestic-support\resources\views\anonymous\confirmation.blade.php ENDPATH**/ ?>