<?php if (isset($component)) { $__componentOriginal58c831a7c3cbf004f2e66a23aed50e5b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal58c831a7c3cbf004f2e66a23aed50e5b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.public-layout','data' => ['title' => 'FAQs']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('public-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'FAQs']); ?>
    <main>
        <section class="public-page-hero bg-gradient-to-br from-teal-950 via-teal-900 to-slate-950 py-20 text-white">
            <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
                <div class="max-w-3xl">
                    <p class="text-sm font-semibold uppercase text-teal-100">Frequently asked questions</p>
                    <h1 class="mt-3 text-4xl font-bold leading-tight">Common questions</h1>
                    <p class="mt-5 text-base leading-7 text-teal-50">
                        Clear answers about public information, privacy, support requests, and role-based access.
                    </p>
                </div>
            </div>
        </section>

        <section class="bg-white py-12">
            <div class="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <section class="border-b border-gray-200 py-8 first:pt-0 last:border-b-0 last:pb-0">
                        <div>
                            <h2 class="text-xl font-semibold text-gray-900"><?php echo e($category->name); ?></h2>
                            <?php if($category->description): ?>
                                <p class="mt-2 text-sm leading-6 text-gray-600"><?php echo e($category->description); ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="mt-6 divide-y divide-gray-200">
                            <?php $__currentLoopData = $category->faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <article class="py-5 first:pt-0 last:pb-0">
                                    <h3 class="text-lg font-semibold text-gray-900"><?php echo e($faq->question); ?></h3>
                                    <p class="mt-3 whitespace-pre-line text-sm leading-6 text-gray-600"><?php echo e($faq->answer); ?></p>
                                </article>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </section>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="rounded-md border border-gray-200 bg-gray-50 p-6 text-sm leading-6 text-gray-600">
                        FAQs will appear here after they are published by an administrator.
                    </div>
                <?php endif; ?>
            </div>
        </section>
    </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal58c831a7c3cbf004f2e66a23aed50e5b)): ?>
<?php $attributes = $__attributesOriginal58c831a7c3cbf004f2e66a23aed50e5b; ?>
<?php unset($__attributesOriginal58c831a7c3cbf004f2e66a23aed50e5b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal58c831a7c3cbf004f2e66a23aed50e5b)): ?>
<?php $component = $__componentOriginal58c831a7c3cbf004f2e66a23aed50e5b; ?>
<?php unset($__componentOriginal58c831a7c3cbf004f2e66a23aed50e5b); ?>
<?php endif; ?>
<?php /**PATH C:\Users\mailp\Documents\VIBECODE\PROJECTS\domestic-support\resources\views\public\faqs.blade.php ENDPATH**/ ?>